#ifndef Z3_MAJOR_VERSION
#define Z3_MAJOR_VERSION 0
#endif

#ifndef Z3_MINOR_VERSION
#define Z3_MINOR_VERSION 0
#endif

#ifndef Z3_BUILD_NUMBER
#define Z3_BUILD_NUMBER 0
#endif


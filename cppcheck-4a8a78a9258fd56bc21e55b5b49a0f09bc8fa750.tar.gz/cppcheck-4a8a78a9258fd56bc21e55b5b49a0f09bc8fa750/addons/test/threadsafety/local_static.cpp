struct Dummy {
 int x;
};
void func() {
  static Dummy dummy;
}
